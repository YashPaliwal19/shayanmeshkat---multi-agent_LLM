# Experiments

Each environment has a folder associated with it. Those folders define the maps. reward machines, and test scenarios per environment. They also include the list of *options* to be used by the Hierarchical RL baselines when solving each task. 
